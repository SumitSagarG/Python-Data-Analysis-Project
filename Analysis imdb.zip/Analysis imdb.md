### Importing Necessary Libraries


```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
```

### Importing Data


```python
 data = pd.read_csv(r"C:\Users\Sumit\Downloads\archive (4)\IMDB-Movie-Data.csv")
```

### 1. Display top 10 rows of Dataset


```python
data.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Guardians of the Galaxy</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>A group of intergalactic criminals are forced ...</td>
      <td>James Gunn</td>
      <td>Chris Pratt, Vin Diesel, Bradley Cooper, Zoe S...</td>
      <td>2014</td>
      <td>121</td>
      <td>8.1</td>
      <td>757074</td>
      <td>333.13</td>
      <td>76.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Prometheus</td>
      <td>Adventure,Mystery,Sci-Fi</td>
      <td>Following clues to the origin of mankind, a te...</td>
      <td>Ridley Scott</td>
      <td>Noomi Rapace, Logan Marshall-Green, Michael Fa...</td>
      <td>2012</td>
      <td>124</td>
      <td>7.0</td>
      <td>485820</td>
      <td>126.46</td>
      <td>65.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Split</td>
      <td>Horror,Thriller</td>
      <td>Three girls are kidnapped by a man with a diag...</td>
      <td>M. Night Shyamalan</td>
      <td>James McAvoy, Anya Taylor-Joy, Haley Lu Richar...</td>
      <td>2016</td>
      <td>117</td>
      <td>7.3</td>
      <td>157606</td>
      <td>138.12</td>
      <td>62.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Sing</td>
      <td>Animation,Comedy,Family</td>
      <td>In a city of humanoid animals, a hustling thea...</td>
      <td>Christophe Lourdelet</td>
      <td>Matthew McConaughey,Reese Witherspoon, Seth Ma...</td>
      <td>2016</td>
      <td>108</td>
      <td>7.2</td>
      <td>60545</td>
      <td>270.32</td>
      <td>59.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Suicide Squad</td>
      <td>Action,Adventure,Fantasy</td>
      <td>A secret government agency recruits some of th...</td>
      <td>David Ayer</td>
      <td>Will Smith, Jared Leto, Margot Robbie, Viola D...</td>
      <td>2016</td>
      <td>123</td>
      <td>6.2</td>
      <td>393727</td>
      <td>325.02</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>The Great Wall</td>
      <td>Action,Adventure,Fantasy</td>
      <td>European mercenaries searching for black powde...</td>
      <td>Yimou Zhang</td>
      <td>Matt Damon, Tian Jing, Willem Dafoe, Andy Lau</td>
      <td>2016</td>
      <td>103</td>
      <td>6.1</td>
      <td>56036</td>
      <td>45.13</td>
      <td>42.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>La La Land</td>
      <td>Comedy,Drama,Music</td>
      <td>A jazz pianist falls for an aspiring actress i...</td>
      <td>Damien Chazelle</td>
      <td>Ryan Gosling, Emma Stone, Rosemarie DeWitt, J....</td>
      <td>2016</td>
      <td>128</td>
      <td>8.3</td>
      <td>258682</td>
      <td>151.06</td>
      <td>93.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>Mindhorn</td>
      <td>Comedy</td>
      <td>A has-been actor best known for playing the ti...</td>
      <td>Sean Foley</td>
      <td>Essie Davis, Andrea Riseborough, Julian Barrat...</td>
      <td>2016</td>
      <td>89</td>
      <td>6.4</td>
      <td>2490</td>
      <td>NaN</td>
      <td>71.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>The Lost City of Z</td>
      <td>Action,Adventure,Biography</td>
      <td>A true-life drama, centering on British explor...</td>
      <td>James Gray</td>
      <td>Charlie Hunnam, Robert Pattinson, Sienna Mille...</td>
      <td>2016</td>
      <td>141</td>
      <td>7.1</td>
      <td>7188</td>
      <td>8.01</td>
      <td>78.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>Passengers</td>
      <td>Adventure,Drama,Romance</td>
      <td>A spacecraft traveling to a distant colony pla...</td>
      <td>Morten Tyldum</td>
      <td>Jennifer Lawrence, Chris Pratt, Michael Sheen,...</td>
      <td>2016</td>
      <td>116</td>
      <td>7.0</td>
      <td>192177</td>
      <td>100.01</td>
      <td>41.0</td>
    </tr>
  </tbody>
</table>
</div>



### 2. Check last 10 rows of dataset


```python
data.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>990</th>
      <td>991</td>
      <td>Underworld: Rise of the Lycans</td>
      <td>Action,Adventure,Fantasy</td>
      <td>An origins story centered on the centuries-old...</td>
      <td>Patrick Tatopoulos</td>
      <td>Rhona Mitra, Michael Sheen, Bill Nighy, Steven...</td>
      <td>2009</td>
      <td>92</td>
      <td>6.6</td>
      <td>129708</td>
      <td>45.80</td>
      <td>44.0</td>
    </tr>
    <tr>
      <th>991</th>
      <td>992</td>
      <td>Taare Zameen Par</td>
      <td>Drama,Family,Music</td>
      <td>An eight-year-old boy is thought to be a lazy ...</td>
      <td>Aamir Khan</td>
      <td>Darsheel Safary, Aamir Khan, Tanay Chheda, Sac...</td>
      <td>2007</td>
      <td>165</td>
      <td>8.5</td>
      <td>102697</td>
      <td>1.20</td>
      <td>42.0</td>
    </tr>
    <tr>
      <th>992</th>
      <td>993</td>
      <td>Take Me Home Tonight</td>
      <td>Comedy,Drama,Romance</td>
      <td>Four years after graduation, an awkward high s...</td>
      <td>Michael Dowse</td>
      <td>Topher Grace, Anna Faris, Dan Fogler, Teresa P...</td>
      <td>2011</td>
      <td>97</td>
      <td>6.3</td>
      <td>45419</td>
      <td>6.92</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>993</th>
      <td>994</td>
      <td>Resident Evil: Afterlife</td>
      <td>Action,Adventure,Horror</td>
      <td>While still out to destroy the evil Umbrella C...</td>
      <td>Paul W.S. Anderson</td>
      <td>Milla Jovovich, Ali Larter, Wentworth Miller,K...</td>
      <td>2010</td>
      <td>97</td>
      <td>5.9</td>
      <td>140900</td>
      <td>60.13</td>
      <td>37.0</td>
    </tr>
    <tr>
      <th>994</th>
      <td>995</td>
      <td>Project X</td>
      <td>Comedy</td>
      <td>3 high school seniors throw a birthday party t...</td>
      <td>Nima Nourizadeh</td>
      <td>Thomas Mann, Oliver Cooper, Jonathan Daniel Br...</td>
      <td>2012</td>
      <td>88</td>
      <td>6.7</td>
      <td>164088</td>
      <td>54.72</td>
      <td>48.0</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Secret in Their Eyes</td>
      <td>Crime,Drama,Mystery</td>
      <td>A tight-knit team of rising investigators, alo...</td>
      <td>Billy Ray</td>
      <td>Chiwetel Ejiofor, Nicole Kidman, Julia Roberts...</td>
      <td>2015</td>
      <td>111</td>
      <td>6.2</td>
      <td>27585</td>
      <td>NaN</td>
      <td>45.0</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hostel: Part II</td>
      <td>Horror</td>
      <td>Three American college students studying abroa...</td>
      <td>Eli Roth</td>
      <td>Lauren German, Heather Matarazzo, Bijou Philli...</td>
      <td>2007</td>
      <td>94</td>
      <td>5.5</td>
      <td>73152</td>
      <td>17.54</td>
      <td>46.0</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Step Up 2: The Streets</td>
      <td>Drama,Music,Romance</td>
      <td>Romantic sparks occur between two dance studen...</td>
      <td>Jon M. Chu</td>
      <td>Robert Hoffman, Briana Evigan, Cassie Ventura,...</td>
      <td>2008</td>
      <td>98</td>
      <td>6.2</td>
      <td>70699</td>
      <td>58.01</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Search Party</td>
      <td>Adventure,Comedy</td>
      <td>A pair of friends embark on a mission to reuni...</td>
      <td>Scot Armstrong</td>
      <td>Adam Pally, T.J. Miller, Thomas Middleditch,Sh...</td>
      <td>2014</td>
      <td>93</td>
      <td>5.6</td>
      <td>4881</td>
      <td>NaN</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Nine Lives</td>
      <td>Comedy,Family,Fantasy</td>
      <td>A stuffy businessman finds himself trapped ins...</td>
      <td>Barry Sonnenfeld</td>
      <td>Kevin Spacey, Jennifer Garner, Robbie Amell,Ch...</td>
      <td>2016</td>
      <td>87</td>
      <td>5.3</td>
      <td>12435</td>
      <td>19.64</td>
      <td>11.0</td>
    </tr>
  </tbody>
</table>
</div>



### 3. Find shape of dataset (no. fo rows and columns):


```python
data.shape #shape is attribute of pandas and not a method
```




    (1000, 12)




```python
print("no of rows", data.shape [0])
print("no of colums", data.shape [1])
```

    no of rows 1000
    no of colums 12
    

### 4. Getting Information About Our Dataset Like Total Number Rows, Total Number of Columns, Datatypes of Each Column And Memory Requirement


```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1000 entries, 0 to 999
    Data columns (total 12 columns):
     #   Column              Non-Null Count  Dtype  
    ---  ------              --------------  -----  
     0   Rank                1000 non-null   int64  
     1   Title               1000 non-null   object 
     2   Genre               1000 non-null   object 
     3   Description         1000 non-null   object 
     4   Director            1000 non-null   object 
     5   Actors              1000 non-null   object 
     6   Year                1000 non-null   int64  
     7   Runtime (Minutes)   1000 non-null   int64  
     8   Rating              1000 non-null   float64
     9   Votes               1000 non-null   int64  
     10  Revenue (Millions)  872 non-null    float64
     11  Metascore           936 non-null    float64
    dtypes: float64(3), int64(4), object(5)
    memory usage: 93.9+ KB
    

### 5. Check Missing Values In The Dataset


```python
print("Any missing value", data.isnull().values.any())
```

    Any missing value True
    


```python
data.isnull().sum()
```




    Rank                    0
    Title                   0
    Genre                   0
    Description             0
    Director                0
    Actors                  0
    Year                    0
    Runtime (Minutes)       0
    Rating                  0
    Votes                   0
    Revenue (Millions)    128
    Metascore              64
    dtype: int64




```python
sns.heatmap(data.isnull())
```




    <Axes: >




    
![png](output_16_1.png)
    



```python
per_missing = data.isnull().sum () * 100/ len(data)
per_missing
```




    Rank                   0.0
    Title                  0.0
    Genre                  0.0
    Description            0.0
    Director               0.0
    Actors                 0.0
    Year                   0.0
    Runtime (Minutes)      0.0
    Rating                 0.0
    Votes                  0.0
    Revenue (Millions)    12.8
    Metascore              6.4
    dtype: float64



### 6. Drop All The  Missing Values


```python
data.dropna(axis=0)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Guardians of the Galaxy</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>A group of intergalactic criminals are forced ...</td>
      <td>James Gunn</td>
      <td>Chris Pratt, Vin Diesel, Bradley Cooper, Zoe S...</td>
      <td>2014</td>
      <td>121</td>
      <td>8.1</td>
      <td>757074</td>
      <td>333.13</td>
      <td>76.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Prometheus</td>
      <td>Adventure,Mystery,Sci-Fi</td>
      <td>Following clues to the origin of mankind, a te...</td>
      <td>Ridley Scott</td>
      <td>Noomi Rapace, Logan Marshall-Green, Michael Fa...</td>
      <td>2012</td>
      <td>124</td>
      <td>7.0</td>
      <td>485820</td>
      <td>126.46</td>
      <td>65.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Split</td>
      <td>Horror,Thriller</td>
      <td>Three girls are kidnapped by a man with a diag...</td>
      <td>M. Night Shyamalan</td>
      <td>James McAvoy, Anya Taylor-Joy, Haley Lu Richar...</td>
      <td>2016</td>
      <td>117</td>
      <td>7.3</td>
      <td>157606</td>
      <td>138.12</td>
      <td>62.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Sing</td>
      <td>Animation,Comedy,Family</td>
      <td>In a city of humanoid animals, a hustling thea...</td>
      <td>Christophe Lourdelet</td>
      <td>Matthew McConaughey,Reese Witherspoon, Seth Ma...</td>
      <td>2016</td>
      <td>108</td>
      <td>7.2</td>
      <td>60545</td>
      <td>270.32</td>
      <td>59.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Suicide Squad</td>
      <td>Action,Adventure,Fantasy</td>
      <td>A secret government agency recruits some of th...</td>
      <td>David Ayer</td>
      <td>Will Smith, Jared Leto, Margot Robbie, Viola D...</td>
      <td>2016</td>
      <td>123</td>
      <td>6.2</td>
      <td>393727</td>
      <td>325.02</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>993</th>
      <td>994</td>
      <td>Resident Evil: Afterlife</td>
      <td>Action,Adventure,Horror</td>
      <td>While still out to destroy the evil Umbrella C...</td>
      <td>Paul W.S. Anderson</td>
      <td>Milla Jovovich, Ali Larter, Wentworth Miller,K...</td>
      <td>2010</td>
      <td>97</td>
      <td>5.9</td>
      <td>140900</td>
      <td>60.13</td>
      <td>37.0</td>
    </tr>
    <tr>
      <th>994</th>
      <td>995</td>
      <td>Project X</td>
      <td>Comedy</td>
      <td>3 high school seniors throw a birthday party t...</td>
      <td>Nima Nourizadeh</td>
      <td>Thomas Mann, Oliver Cooper, Jonathan Daniel Br...</td>
      <td>2012</td>
      <td>88</td>
      <td>6.7</td>
      <td>164088</td>
      <td>54.72</td>
      <td>48.0</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hostel: Part II</td>
      <td>Horror</td>
      <td>Three American college students studying abroa...</td>
      <td>Eli Roth</td>
      <td>Lauren German, Heather Matarazzo, Bijou Philli...</td>
      <td>2007</td>
      <td>94</td>
      <td>5.5</td>
      <td>73152</td>
      <td>17.54</td>
      <td>46.0</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Step Up 2: The Streets</td>
      <td>Drama,Music,Romance</td>
      <td>Romantic sparks occur between two dance studen...</td>
      <td>Jon M. Chu</td>
      <td>Robert Hoffman, Briana Evigan, Cassie Ventura,...</td>
      <td>2008</td>
      <td>98</td>
      <td>6.2</td>
      <td>70699</td>
      <td>58.01</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Nine Lives</td>
      <td>Comedy,Family,Fantasy</td>
      <td>A stuffy businessman finds himself trapped ins...</td>
      <td>Barry Sonnenfeld</td>
      <td>Kevin Spacey, Jennifer Garner, Robbie Amell,Ch...</td>
      <td>2016</td>
      <td>87</td>
      <td>5.3</td>
      <td>12435</td>
      <td>19.64</td>
      <td>11.0</td>
    </tr>
  </tbody>
</table>
<p>838 rows × 12 columns</p>
</div>



### 7. Check For Duplicate Data


```python
dup_data = data.duplicated().any()
```


```python
print("are there any duplicate values?", dup_data)
```

    are there any duplicate values? False
    


```python
data = data.drop_duplicates()
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Guardians of the Galaxy</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>A group of intergalactic criminals are forced ...</td>
      <td>James Gunn</td>
      <td>Chris Pratt, Vin Diesel, Bradley Cooper, Zoe S...</td>
      <td>2014</td>
      <td>121</td>
      <td>8.1</td>
      <td>757074</td>
      <td>333.13</td>
      <td>76.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Prometheus</td>
      <td>Adventure,Mystery,Sci-Fi</td>
      <td>Following clues to the origin of mankind, a te...</td>
      <td>Ridley Scott</td>
      <td>Noomi Rapace, Logan Marshall-Green, Michael Fa...</td>
      <td>2012</td>
      <td>124</td>
      <td>7.0</td>
      <td>485820</td>
      <td>126.46</td>
      <td>65.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Split</td>
      <td>Horror,Thriller</td>
      <td>Three girls are kidnapped by a man with a diag...</td>
      <td>M. Night Shyamalan</td>
      <td>James McAvoy, Anya Taylor-Joy, Haley Lu Richar...</td>
      <td>2016</td>
      <td>117</td>
      <td>7.3</td>
      <td>157606</td>
      <td>138.12</td>
      <td>62.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Sing</td>
      <td>Animation,Comedy,Family</td>
      <td>In a city of humanoid animals, a hustling thea...</td>
      <td>Christophe Lourdelet</td>
      <td>Matthew McConaughey,Reese Witherspoon, Seth Ma...</td>
      <td>2016</td>
      <td>108</td>
      <td>7.2</td>
      <td>60545</td>
      <td>270.32</td>
      <td>59.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Suicide Squad</td>
      <td>Action,Adventure,Fantasy</td>
      <td>A secret government agency recruits some of th...</td>
      <td>David Ayer</td>
      <td>Will Smith, Jared Leto, Margot Robbie, Viola D...</td>
      <td>2016</td>
      <td>123</td>
      <td>6.2</td>
      <td>393727</td>
      <td>325.02</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Secret in Their Eyes</td>
      <td>Crime,Drama,Mystery</td>
      <td>A tight-knit team of rising investigators, alo...</td>
      <td>Billy Ray</td>
      <td>Chiwetel Ejiofor, Nicole Kidman, Julia Roberts...</td>
      <td>2015</td>
      <td>111</td>
      <td>6.2</td>
      <td>27585</td>
      <td>NaN</td>
      <td>45.0</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hostel: Part II</td>
      <td>Horror</td>
      <td>Three American college students studying abroa...</td>
      <td>Eli Roth</td>
      <td>Lauren German, Heather Matarazzo, Bijou Philli...</td>
      <td>2007</td>
      <td>94</td>
      <td>5.5</td>
      <td>73152</td>
      <td>17.54</td>
      <td>46.0</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Step Up 2: The Streets</td>
      <td>Drama,Music,Romance</td>
      <td>Romantic sparks occur between two dance studen...</td>
      <td>Jon M. Chu</td>
      <td>Robert Hoffman, Briana Evigan, Cassie Ventura,...</td>
      <td>2008</td>
      <td>98</td>
      <td>6.2</td>
      <td>70699</td>
      <td>58.01</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Search Party</td>
      <td>Adventure,Comedy</td>
      <td>A pair of friends embark on a mission to reuni...</td>
      <td>Scot Armstrong</td>
      <td>Adam Pally, T.J. Miller, Thomas Middleditch,Sh...</td>
      <td>2014</td>
      <td>93</td>
      <td>5.6</td>
      <td>4881</td>
      <td>NaN</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Nine Lives</td>
      <td>Comedy,Family,Fantasy</td>
      <td>A stuffy businessman finds himself trapped ins...</td>
      <td>Barry Sonnenfeld</td>
      <td>Kevin Spacey, Jennifer Garner, Robbie Amell,Ch...</td>
      <td>2016</td>
      <td>87</td>
      <td>5.3</td>
      <td>12435</td>
      <td>19.64</td>
      <td>11.0</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 12 columns</p>
</div>



### 8. Get Overall Statistics About The DataFrame


```python
data.describe(include = "all")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1000.000000</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1.000000e+03</td>
      <td>872.000000</td>
      <td>936.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>NaN</td>
      <td>999</td>
      <td>207</td>
      <td>1000</td>
      <td>644</td>
      <td>996</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>NaN</td>
      <td>The Host</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>A group of intergalactic criminals are forced ...</td>
      <td>Ridley Scott</td>
      <td>Jennifer Lawrence, Josh Hutcherson, Liam Hemsw...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>NaN</td>
      <td>2</td>
      <td>50</td>
      <td>1</td>
      <td>8</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>500.500000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2012.783000</td>
      <td>113.172000</td>
      <td>6.723200</td>
      <td>1.698083e+05</td>
      <td>82.956376</td>
      <td>58.985043</td>
    </tr>
    <tr>
      <th>std</th>
      <td>288.819436</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.205962</td>
      <td>18.810908</td>
      <td>0.945429</td>
      <td>1.887626e+05</td>
      <td>103.253540</td>
      <td>17.194757</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2006.000000</td>
      <td>66.000000</td>
      <td>1.900000</td>
      <td>6.100000e+01</td>
      <td>0.000000</td>
      <td>11.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>250.750000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2010.000000</td>
      <td>100.000000</td>
      <td>6.200000</td>
      <td>3.630900e+04</td>
      <td>13.270000</td>
      <td>47.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>500.500000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2014.000000</td>
      <td>111.000000</td>
      <td>6.800000</td>
      <td>1.107990e+05</td>
      <td>47.985000</td>
      <td>59.500000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>750.250000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2016.000000</td>
      <td>123.000000</td>
      <td>7.400000</td>
      <td>2.399098e+05</td>
      <td>113.715000</td>
      <td>72.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1000.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2016.000000</td>
      <td>191.000000</td>
      <td>9.000000</td>
      <td>1.791916e+06</td>
      <td>936.630000</td>
      <td>100.000000</td>
    </tr>
  </tbody>
</table>
</div>



### 9. Display Title of The Movie Having Runtime Greater Than or equal to 180 Minutes


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
data[data['Runtime (Minutes)']>=180]['Title']
```




    82     The Wolf of Wall Street
    88           The Hateful Eight
    311             La vie d'Adèle
    828                 Grindhouse
    965              Inland Empire
    Name: Title, dtype: object



### 10. In Which Year There Was The Highest Average Voting?


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
data.groupby('Year')['Votes'].mean().sort_values(ascending = False)
```




    Year
    2012    285226.093750
    2008    275505.384615
    2006    269289.954545
    2009    255780.647059
    2010    252782.316667
    2007    244331.037736
    2011    240790.301587
    2013    219049.648352
    2014    203930.224490
    2015    115726.220472
    2016     48591.754209
    Name: Votes, dtype: float64




```python
sns.barplot(x= 'Year', y = 'Votes', data = data)
plt.title("votes by year")
plt.show
```




    <function matplotlib.pyplot.show(close=None, block=None)>




    
![png](output_32_1.png)
    


### 11. In Which Year There Was The Highest Average Revenue?


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
data.groupby('Year')['Revenue (Millions)'].mean().sort_values(ascending = False)
```




    Year
    2009    112.601277
    2012    107.973281
    2010    105.081579
    2008     99.082745
    2007     87.882245
    2011     87.612258
    2013     87.121818
    2006     86.296667
    2014     85.078723
    2015     78.355044
    2016     54.690976
    Name: Revenue (Millions), dtype: float64




```python
sns.barplot(x= 'Year', y = 'Revenue (Millions)', data = data)
plt.title("Revnue by Year")
plt.show
```




    <function matplotlib.pyplot.show(close=None, block=None)>




    
![png](output_36_1.png)
    


### 12. Find The Average Rating For Each Director


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
data.groupby('Director')['Rating'].mean().sort_values(ascending = False)
```




    Director
    Nitesh Tiwari        8.80
    Christopher Nolan    8.68
    Olivier Nakache      8.60
    Makoto Shinkai       8.60
    Aamir Khan           8.50
                         ... 
    Micheal Bafaro       3.50
    Jonathan Holbrook    3.20
    Shawn Burkett        2.70
    James Wong           2.70
    Jason Friedberg      1.90
    Name: Rating, Length: 644, dtype: float64



### 13. Display Top 10 Lengthy Movies Title and Runtime


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
top10_len=data.nlargest(10, 'Runtime (Minutes)')[['Title', 'Runtime (Minutes)']]\
.set_index('Title')
```


```python
top10_len
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Runtime (Minutes)</th>
    </tr>
    <tr>
      <th>Title</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Grindhouse</th>
      <td>191</td>
    </tr>
    <tr>
      <th>The Hateful Eight</th>
      <td>187</td>
    </tr>
    <tr>
      <th>The Wolf of Wall Street</th>
      <td>180</td>
    </tr>
    <tr>
      <th>La vie d'Adèle</th>
      <td>180</td>
    </tr>
    <tr>
      <th>Inland Empire</th>
      <td>180</td>
    </tr>
    <tr>
      <th>Cloud Atlas</th>
      <td>172</td>
    </tr>
    <tr>
      <th>3 Idiots</th>
      <td>170</td>
    </tr>
    <tr>
      <th>Interstellar</th>
      <td>169</td>
    </tr>
    <tr>
      <th>Pirates of the Caribbean: At World's End</th>
      <td>169</td>
    </tr>
    <tr>
      <th>The Hobbit: An Unexpected Journey</th>
      <td>169</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.barplot(x= 'Runtime (Minutes)', y = top10_len.index, data = top10_len)
```




    <Axes: xlabel='Runtime (Minutes)', ylabel='Title'>




    
![png](output_44_1.png)
    


### 14. Display Number of Movies Per Year


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
data['Year'].value_counts()
```




    Year
    2016    297
    2015    127
    2014     98
    2013     91
    2012     64
    2011     63
    2010     60
    2007     53
    2008     52
    2009     51
    2006     44
    Name: count, dtype: int64




```python
sns.countplot(x='Year', data= data)
plt.title("No of movies per year")
plt.show()
```


    
![png](output_48_0.png)
    


### 15. Find Most Popular Movie Title (Highest Revenue)


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
data[data['Revenue (Millions)'].max() == data['Revenue (Millions)']]['Title']
```




    50    Star Wars: Episode VII - The Force Awakens
    Name: Title, dtype: object



### 16. Display Top 10 Highest Rated Movie Titles And its Directors



```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
top10_len=data.nlargest(10, 'Rating')[['Title', 'Rating', 'Director']]\
.set_index('Title')
```


```python
top10_len
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rating</th>
      <th>Director</th>
    </tr>
    <tr>
      <th>Title</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>The Dark Knight</th>
      <td>9.0</td>
      <td>Christopher Nolan</td>
    </tr>
    <tr>
      <th>Inception</th>
      <td>8.8</td>
      <td>Christopher Nolan</td>
    </tr>
    <tr>
      <th>Dangal</th>
      <td>8.8</td>
      <td>Nitesh Tiwari</td>
    </tr>
    <tr>
      <th>Interstellar</th>
      <td>8.6</td>
      <td>Christopher Nolan</td>
    </tr>
    <tr>
      <th>Kimi no na wa</th>
      <td>8.6</td>
      <td>Makoto Shinkai</td>
    </tr>
    <tr>
      <th>The Intouchables</th>
      <td>8.6</td>
      <td>Olivier Nakache</td>
    </tr>
    <tr>
      <th>The Prestige</th>
      <td>8.5</td>
      <td>Christopher Nolan</td>
    </tr>
    <tr>
      <th>The Departed</th>
      <td>8.5</td>
      <td>Martin Scorsese</td>
    </tr>
    <tr>
      <th>The Dark Knight Rises</th>
      <td>8.5</td>
      <td>Christopher Nolan</td>
    </tr>
    <tr>
      <th>Whiplash</th>
      <td>8.5</td>
      <td>Damien Chazelle</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.barplot(x= 'Rating', y=top10_len.index, data=top10_len, hue = 'Director')
plt.legend(bbox_to_anchor = (1.05,1), loc = 2)
```




    <matplotlib.legend.Legend at 0x1c52540e6c0>




    
![png](output_56_1.png)
    


### 17. Display Top 10 Highest Revenue Movie Titles


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
data.nlargest(10, 'Revenue (Millions)')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>50</th>
      <td>51</td>
      <td>Star Wars: Episode VII - The Force Awakens</td>
      <td>Action,Adventure,Fantasy</td>
      <td>Three decades after the defeat of the Galactic...</td>
      <td>J.J. Abrams</td>
      <td>Daisy Ridley, John Boyega, Oscar Isaac, Domhna...</td>
      <td>2015</td>
      <td>136</td>
      <td>8.1</td>
      <td>661608</td>
      <td>936.63</td>
      <td>81.0</td>
    </tr>
    <tr>
      <th>87</th>
      <td>88</td>
      <td>Avatar</td>
      <td>Action,Adventure,Fantasy</td>
      <td>A paraplegic marine dispatched to the moon Pan...</td>
      <td>James Cameron</td>
      <td>Sam Worthington, Zoe Saldana, Sigourney Weaver...</td>
      <td>2009</td>
      <td>162</td>
      <td>7.8</td>
      <td>935408</td>
      <td>760.51</td>
      <td>83.0</td>
    </tr>
    <tr>
      <th>85</th>
      <td>86</td>
      <td>Jurassic World</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>A new theme park, built on the original site o...</td>
      <td>Colin Trevorrow</td>
      <td>Chris Pratt, Bryce Dallas Howard, Ty Simpkins,...</td>
      <td>2015</td>
      <td>124</td>
      <td>7.0</td>
      <td>455169</td>
      <td>652.18</td>
      <td>59.0</td>
    </tr>
    <tr>
      <th>76</th>
      <td>77</td>
      <td>The Avengers</td>
      <td>Action,Sci-Fi</td>
      <td>Earth's mightiest heroes must come together an...</td>
      <td>Joss Whedon</td>
      <td>Robert Downey Jr., Chris Evans, Scarlett Johan...</td>
      <td>2012</td>
      <td>143</td>
      <td>8.1</td>
      <td>1045588</td>
      <td>623.28</td>
      <td>69.0</td>
    </tr>
    <tr>
      <th>54</th>
      <td>55</td>
      <td>The Dark Knight</td>
      <td>Action,Crime,Drama</td>
      <td>When the menace known as the Joker wreaks havo...</td>
      <td>Christopher Nolan</td>
      <td>Christian Bale, Heath Ledger, Aaron Eckhart,Mi...</td>
      <td>2008</td>
      <td>152</td>
      <td>9.0</td>
      <td>1791916</td>
      <td>533.32</td>
      <td>82.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>13</td>
      <td>Rogue One</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>The Rebel Alliance makes a risky move to steal...</td>
      <td>Gareth Edwards</td>
      <td>Felicity Jones, Diego Luna, Alan Tudyk, Donnie...</td>
      <td>2016</td>
      <td>133</td>
      <td>7.9</td>
      <td>323118</td>
      <td>532.17</td>
      <td>65.0</td>
    </tr>
    <tr>
      <th>119</th>
      <td>120</td>
      <td>Finding Dory</td>
      <td>Animation,Adventure,Comedy</td>
      <td>The friendly but forgetful blue tang fish, Dor...</td>
      <td>Andrew Stanton</td>
      <td>Ellen DeGeneres, Albert Brooks,Ed O'Neill, Kai...</td>
      <td>2016</td>
      <td>97</td>
      <td>7.4</td>
      <td>157026</td>
      <td>486.29</td>
      <td>77.0</td>
    </tr>
    <tr>
      <th>94</th>
      <td>95</td>
      <td>Avengers: Age of Ultron</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>When Tony Stark and Bruce Banner try to jump-s...</td>
      <td>Joss Whedon</td>
      <td>Robert Downey Jr., Chris Evans, Mark Ruffalo, ...</td>
      <td>2015</td>
      <td>141</td>
      <td>7.4</td>
      <td>516895</td>
      <td>458.99</td>
      <td>66.0</td>
    </tr>
    <tr>
      <th>124</th>
      <td>125</td>
      <td>The Dark Knight Rises</td>
      <td>Action,Thriller</td>
      <td>Eight years after the Joker's reign of anarchy...</td>
      <td>Christopher Nolan</td>
      <td>Christian Bale, Tom Hardy, Anne Hathaway,Gary ...</td>
      <td>2012</td>
      <td>164</td>
      <td>8.5</td>
      <td>1222645</td>
      <td>448.13</td>
      <td>78.0</td>
    </tr>
    <tr>
      <th>578</th>
      <td>579</td>
      <td>The Hunger Games: Catching Fire</td>
      <td>Action,Adventure,Mystery</td>
      <td>Katniss Everdeen and Peeta Mellark become targ...</td>
      <td>Francis Lawrence</td>
      <td>Jennifer Lawrence, Josh Hutcherson, Liam Hemsw...</td>
      <td>2013</td>
      <td>146</td>
      <td>7.6</td>
      <td>525646</td>
      <td>424.65</td>
      <td>76.0</td>
    </tr>
  </tbody>
</table>
</div>



### 18.  Find Average Rating of Movies Year Wise


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
data.groupby('Year')['Rating'].mean().sort_values (ascending = False)
```




    Year
    2007    7.133962
    2006    7.125000
    2009    6.960784
    2012    6.925000
    2011    6.838095
    2014    6.837755
    2010    6.826667
    2013    6.812088
    2008    6.784615
    2015    6.602362
    2016    6.436700
    Name: Rating, dtype: float64



### 19. Does Rating Affect The Revenue?


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
sns.scatterplot(x= 'Rating', y='Revenue (Millions)', data =data)
```




    <Axes: xlabel='Rating', ylabel='Revenue (Millions)'>




    
![png](output_65_1.png)
    


### 20. Classify Movies Based on Ratings [Excellent, Good, and Average]


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
def rating(rating):
    if rating >= 7.0:
        return "Excellent"
    elif rating>=6.0:
        return "Good"
    else:
        return "Average"
```


```python
data['rating_cat']=data['Rating'].apply(rating)
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
      <th>rating_cat</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Guardians of the Galaxy</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>A group of intergalactic criminals are forced ...</td>
      <td>James Gunn</td>
      <td>Chris Pratt, Vin Diesel, Bradley Cooper, Zoe S...</td>
      <td>2014</td>
      <td>121</td>
      <td>8.1</td>
      <td>757074</td>
      <td>333.13</td>
      <td>76.0</td>
      <td>Excellent</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Prometheus</td>
      <td>Adventure,Mystery,Sci-Fi</td>
      <td>Following clues to the origin of mankind, a te...</td>
      <td>Ridley Scott</td>
      <td>Noomi Rapace, Logan Marshall-Green, Michael Fa...</td>
      <td>2012</td>
      <td>124</td>
      <td>7.0</td>
      <td>485820</td>
      <td>126.46</td>
      <td>65.0</td>
      <td>Excellent</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Split</td>
      <td>Horror,Thriller</td>
      <td>Three girls are kidnapped by a man with a diag...</td>
      <td>M. Night Shyamalan</td>
      <td>James McAvoy, Anya Taylor-Joy, Haley Lu Richar...</td>
      <td>2016</td>
      <td>117</td>
      <td>7.3</td>
      <td>157606</td>
      <td>138.12</td>
      <td>62.0</td>
      <td>Excellent</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Sing</td>
      <td>Animation,Comedy,Family</td>
      <td>In a city of humanoid animals, a hustling thea...</td>
      <td>Christophe Lourdelet</td>
      <td>Matthew McConaughey,Reese Witherspoon, Seth Ma...</td>
      <td>2016</td>
      <td>108</td>
      <td>7.2</td>
      <td>60545</td>
      <td>270.32</td>
      <td>59.0</td>
      <td>Excellent</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Suicide Squad</td>
      <td>Action,Adventure,Fantasy</td>
      <td>A secret government agency recruits some of th...</td>
      <td>David Ayer</td>
      <td>Will Smith, Jared Leto, Margot Robbie, Viola D...</td>
      <td>2016</td>
      <td>123</td>
      <td>6.2</td>
      <td>393727</td>
      <td>325.02</td>
      <td>40.0</td>
      <td>Good</td>
    </tr>
  </tbody>
</table>
</div>



### 21. Count Number of Action Movies


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore', 'rating_cat'],
          dtype='object')




```python
data['Genre'].dtype
```




    dtype('O')




```python
len(data[data['Genre'].str.contains('Action',case = False)])
```




    303



### 22. Find Unique Values From Genre 


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore', 'rating_cat'],
          dtype='object')




```python
data['Genre']
```




    0       Action,Adventure,Sci-Fi
    1      Adventure,Mystery,Sci-Fi
    2               Horror,Thriller
    3       Animation,Comedy,Family
    4      Action,Adventure,Fantasy
                     ...           
    995         Crime,Drama,Mystery
    996                      Horror
    997         Drama,Music,Romance
    998            Adventure,Comedy
    999       Comedy,Family,Fantasy
    Name: Genre, Length: 1000, dtype: object




```python
list1= []
for value in data['Genre']:
   list1.append(value.split(','))

list1
```




    [['Action', 'Adventure', 'Sci-Fi'],
     ['Adventure', 'Mystery', 'Sci-Fi'],
     ['Horror', 'Thriller'],
     ['Animation', 'Comedy', 'Family'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Comedy', 'Drama', 'Music'],
     ['Comedy'],
     ['Action', 'Adventure', 'Biography'],
     ['Adventure', 'Drama', 'Romance'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Biography', 'Drama', 'History'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Action', 'Comedy', 'Drama'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Biography', 'Drama', 'History'],
     ['Action', 'Thriller'],
     ['Biography', 'Drama'],
     ['Drama', 'Mystery', 'Sci-Fi'],
     ['Adventure', 'Drama', 'Thriller'],
     ['Drama'],
     ['Crime', 'Drama', 'Horror'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Comedy'],
     ['Action', 'Adventure', 'Drama'],
     ['Horror', 'Thriller'],
     ['Comedy'],
     ['Action', 'Adventure', 'Drama'],
     ['Comedy'],
     ['Drama', 'Thriller'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Adventure', 'Comedy'],
     ['Action', 'Horror', 'Sci-Fi'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Adventure', 'Drama', 'Sci-Fi'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Adventure', 'Western'],
     ['Comedy', 'Drama'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Drama'],
     ['Horror'],
     ['Biography', 'Drama', 'History'],
     ['Drama'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Drama', 'Thriller'],
     ['Adventure', 'Drama', 'Fantasy'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Drama'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Comedy', 'Drama'],
     ['Action', 'Crime', 'Thriller'],
     ['Action', 'Crime', 'Drama'],
     ['Adventure', 'Drama', 'History'],
     ['Crime', 'Horror', 'Thriller'],
     ['Drama', 'Romance'],
     ['Comedy', 'Drama', 'Romance'],
     ['Biography', 'Drama'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Horror', 'Mystery', 'Thriller'],
     ['Crime', 'Drama', 'Mystery'],
     ['Drama', 'Romance', 'Thriller'],
     ['Drama', 'Mystery', 'Sci-Fi'],
     ['Action', 'Adventure', 'Comedy'],
     ['Drama', 'History', 'Thriller'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Drama'],
     ['Action', 'Drama', 'Thriller'],
     ['Drama', 'History'],
     ['Action', 'Drama', 'Romance'],
     ['Drama', 'Fantasy'],
     ['Drama', 'Romance'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Sci-Fi'],
     ['Adventure', 'Drama', 'War'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Comedy', 'Fantasy'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Comedy', 'Drama'],
     ['Biography', 'Comedy', 'Crime'],
     ['Crime', 'Drama', 'Mystery'],
     ['Action', 'Crime', 'Thriller'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Crime', 'Drama'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Crime', 'Drama', 'Mystery'],
     ['Action', 'Crime', 'Drama'],
     ['Crime', 'Drama', 'Mystery'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Drama'],
     ['Comedy', 'Crime', 'Drama'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Comedy', 'Crime'],
     ['Animation', 'Drama', 'Fantasy'],
     ['Horror', 'Mystery', 'Sci-Fi'],
     ['Drama', 'Mystery', 'Thriller'],
     ['Crime', 'Drama', 'Thriller'],
     ['Biography', 'Crime', 'Drama'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Adventure', 'Drama', 'Sci-Fi'],
     ['Crime', 'Mystery', 'Thriller'],
     ['Action', 'Adventure', 'Comedy'],
     ['Crime', 'Drama', 'Thriller'],
     ['Comedy'],
     ['Action', 'Adventure', 'Drama'],
     ['Drama'],
     ['Drama', 'Mystery', 'Sci-Fi'],
     ['Action', 'Horror', 'Thriller'],
     ['Biography', 'Drama', 'History'],
     ['Romance', 'Sci-Fi'],
     ['Action', 'Fantasy', 'War'],
     ['Adventure', 'Drama', 'Fantasy'],
     ['Comedy'],
     ['Horror', 'Thriller'],
     ['Action', 'Biography', 'Drama'],
     ['Drama', 'Horror', 'Mystery'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Adventure', 'Drama', 'Family'],
     ['Adventure', 'Mystery', 'Sci-Fi'],
     ['Adventure', 'Comedy', 'Romance'],
     ['Action'],
     ['Action', 'Thriller'],
     ['Adventure', 'Drama', 'Family'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Adventure', 'Crime', 'Mystery'],
     ['Comedy', 'Family', 'Musical'],
     ['Adventure', 'Drama', 'Thriller'],
     ['Drama'],
     ['Adventure', 'Comedy', 'Drama'],
     ['Drama', 'Horror', 'Thriller'],
     ['Drama', 'Music'],
     ['Action', 'Crime', 'Thriller'],
     ['Crime', 'Drama', 'Thriller'],
     ['Crime', 'Drama', 'Thriller'],
     ['Drama', 'Romance'],
     ['Mystery', 'Thriller'],
     ['Mystery', 'Thriller', 'Western'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Comedy', 'Family'],
     ['Biography', 'Comedy', 'Drama'],
     ['Drama'],
     ['Drama', 'Western'],
     ['Drama', 'Mystery', 'Romance'],
     ['Comedy', 'Drama'],
     ['Action', 'Drama', 'Mystery'],
     ['Comedy'],
     ['Action', 'Adventure', 'Crime'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Adventure', 'Sci-Fi', 'Thriller'],
     ['Drama'],
     ['Action', 'Crime', 'Drama'],
     ['Drama', 'Horror', 'Mystery'],
     ['Action', 'Horror', 'Sci-Fi'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Comedy', 'Drama', 'Romance'],
     ['Action', 'Comedy', 'Fantasy'],
     ['Action', 'Comedy', 'Mystery'],
     ['Thriller', 'War'],
     ['Action', 'Comedy', 'Crime'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Adventure', 'Crime'],
     ['Action', 'Adventure', 'Thriller'],
     ['Drama', 'Fantasy', 'Romance'],
     ['Action', 'Adventure', 'Comedy'],
     ['Biography', 'Drama', 'History'],
     ['Action', 'Drama', 'History'],
     ['Action', 'Adventure', 'Thriller'],
     ['Crime', 'Drama', 'Thriller'],
     ['Animation', 'Adventure', 'Family'],
     ['Adventure', 'Horror'],
     ['Drama', 'Romance', 'Sci-Fi'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Action', 'Adventure', 'Family'],
     ['Action', 'Adventure', 'Drama'],
     ['Action', 'Comedy'],
     ['Horror', 'Mystery', 'Thriller'],
     ['Action', 'Adventure', 'Comedy'],
     ['Comedy', 'Romance'],
     ['Horror', 'Mystery'],
     ['Drama', 'Family', 'Fantasy'],
     ['Sci-Fi'],
     ['Drama', 'Thriller'],
     ['Drama', 'Romance'],
     ['Drama', 'War'],
     ['Drama', 'Fantasy', 'Horror'],
     ['Crime', 'Drama'],
     ['Comedy', 'Drama', 'Romance'],
     ['Drama', 'Romance'],
     ['Drama'],
     ['Crime', 'Drama', 'History'],
     ['Horror', 'Sci-Fi', 'Thriller'],
     ['Action', 'Drama', 'Sport'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Crime', 'Drama', 'Thriller'],
     ['Adventure', 'Biography', 'Drama'],
     ['Biography', 'Drama', 'Thriller'],
     ['Action', 'Comedy', 'Crime'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Drama', 'Fantasy', 'Horror'],
     ['Biography', 'Drama', 'Thriller'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Adventure', 'Mystery'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Drama', 'Horror'],
     ['Comedy', 'Drama', 'Romance'],
     ['Comedy', 'Romance'],
     ['Drama', 'Horror', 'Thriller'],
     ['Action', 'Adventure', 'Drama'],
     ['Drama'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Drama', 'Mystery'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Adventure', 'Comedy'],
     ['Drama', 'Horror'],
     ['Action', 'Comedy'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Horror', 'Mystery'],
     ['Crime', 'Drama', 'Mystery'],
     ['Comedy', 'Crime'],
     ['Drama'],
     ['Comedy', 'Drama', 'Romance'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Adventure', 'Family'],
     ['Horror', 'Sci-Fi', 'Thriller'],
     ['Drama', 'Fantasy', 'War'],
     ['Crime', 'Drama', 'Thriller'],
     ['Action', 'Adventure', 'Drama'],
     ['Action', 'Adventure', 'Thriller'],
     ['Action', 'Adventure', 'Drama'],
     ['Drama', 'Romance'],
     ['Biography', 'Drama', 'History'],
     ['Drama', 'Horror', 'Thriller'],
     ['Adventure', 'Comedy', 'Drama'],
     ['Action', 'Adventure', 'Romance'],
     ['Action', 'Drama', 'War'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Drama', 'Musical', 'Romance'],
     ['Drama', 'Sci-Fi', 'Thriller'],
     ['Comedy', 'Drama'],
     ['Action', 'Comedy', 'Crime'],
     ['Biography', 'Comedy', 'Drama'],
     ['Comedy', 'Drama', 'Romance'],
     ['Drama', 'Thriller'],
     ['Biography', 'Drama', 'History'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Horror', 'Mystery', 'Thriller'],
     ['Comedy'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Drama', 'Sci-Fi'],
     ['Horror'],
     ['Drama', 'Thriller'],
     ['Comedy', 'Drama', 'Romance'],
     ['Drama', 'Thriller'],
     ['Comedy', 'Drama'],
     ['Drama'],
     ['Action', 'Adventure', 'Comedy'],
     ['Drama', 'Horror', 'Thriller'],
     ['Comedy'],
     ['Drama', 'Sci-Fi'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Horror'],
     ['Action', 'Adventure', 'Thriller'],
     ['Adventure', 'Fantasy'],
     ['Action', 'Comedy', 'Crime'],
     ['Comedy', 'Drama', 'Music'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Action', 'Adventure', 'Mystery'],
     ['Action', 'Comedy', 'Crime'],
     ['Crime', 'Drama', 'History'],
     ['Comedy'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Crime', 'Mystery', 'Thriller'],
     ['Action', 'Adventure', 'Crime'],
     ['Thriller'],
     ['Biography', 'Drama', 'Romance'],
     ['Action', 'Adventure'],
     ['Action', 'Fantasy'],
     ['Action', 'Comedy'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Comedy', 'Crime'],
     ['Thriller'],
     ['Action', 'Drama', 'Horror'],
     ['Comedy', 'Music', 'Romance'],
     ['Comedy'],
     ['Drama'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Drama', 'Romance'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Comedy', 'Drama'],
     ['Biography', 'Crime', 'Drama'],
     ['Drama', 'History'],
     ['Action', 'Crime', 'Thriller'],
     ['Action', 'Biography', 'Drama'],
     ['Horror'],
     ['Comedy', 'Romance'],
     ['Comedy', 'Romance'],
     ['Comedy', 'Crime', 'Drama'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Crime', 'Drama', 'Thriller'],
     ['Action', 'Crime', 'Thriller'],
     ['Comedy', 'Romance'],
     ['Biography', 'Drama', 'Sport'],
     ['Drama', 'Romance'],
     ['Drama', 'Horror'],
     ['Adventure', 'Fantasy'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Action', 'Drama', 'Sci-Fi'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Horror'],
     ['Comedy', 'Horror', 'Thriller'],
     ['Action', 'Crime', 'Thriller'],
     ['Crime', 'Drama', 'Music'],
     ['Drama'],
     ['Action', 'Crime', 'Thriller'],
     ['Action', 'Sci-Fi', 'Thriller'],
     ['Biography', 'Drama'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Drama', 'Horror', 'Sci-Fi'],
     ['Biography', 'Comedy', 'Drama'],
     ['Crime', 'Horror', 'Thriller'],
     ['Crime', 'Drama', 'Mystery'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Action', 'Biography', 'Drama'],
     ['Biography', 'Drama'],
     ['Biography', 'Drama', 'History'],
     ['Action', 'Biography', 'Drama'],
     ['Drama', 'Fantasy', 'Horror'],
     ['Comedy', 'Drama', 'Romance'],
     ['Drama', 'Sport'],
     ['Drama', 'Romance'],
     ['Comedy', 'Romance'],
     ['Action', 'Crime', 'Thriller'],
     ['Action', 'Crime', 'Drama'],
     ['Action', 'Drama', 'Thriller'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Action', 'Adventure'],
     ['Action', 'Adventure', 'Romance'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Crime', 'Drama'],
     ['Comedy', 'Horror'],
     ['Comedy', 'Fantasy', 'Romance'],
     ['Drama'],
     ['Drama'],
     ['Comedy', 'Drama'],
     ['Comedy', 'Drama', 'Romance'],
     ['Adventure', 'Sci-Fi', 'Thriller'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Comedy', 'Drama'],
     ['Biography', 'Drama', 'Romance'],
     ['Comedy', 'Fantasy'],
     ['Comedy', 'Drama', 'Fantasy'],
     ['Comedy'],
     ['Horror', 'Thriller'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Adventure', 'Comedy', 'Horror'],
     ['Comedy', 'Mystery'],
     ['Drama'],
     ['Adventure', 'Drama', 'Fantasy'],
     ['Drama', 'Sport'],
     ['Action', 'Adventure'],
     ['Action', 'Adventure', 'Drama'],
     ['Action', 'Drama', 'Sci-Fi'],
     ['Action', 'Mystery', 'Sci-Fi'],
     ['Action', 'Crime', 'Drama'],
     ['Action', 'Crime', 'Fantasy'],
     ['Biography', 'Comedy', 'Drama'],
     ['Action', 'Crime', 'Thriller'],
     ['Biography', 'Crime', 'Drama'],
     ['Drama', 'Sport'],
     ['Adventure', 'Comedy', 'Drama'],
     ['Action', 'Adventure', 'Thriller'],
     ['Comedy', 'Fantasy', 'Horror'],
     ['Drama', 'Sport'],
     ['Horror', 'Thriller'],
     ['Drama', 'History', 'Thriller'],
     ['Animation', 'Action', 'Adventure'],
     ['Action', 'Adventure', 'Drama'],
     ['Action', 'Comedy', 'Family'],
     ['Action', 'Adventure', 'Drama'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Comedy'],
     ['Action', 'Crime', 'Drama'],
     ['Biography', 'Drama'],
     ['Comedy', 'Romance'],
     ['Comedy'],
     ['Drama', 'Fantasy', 'Romance'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Comedy'],
     ['Comedy', 'Sci-Fi'],
     ['Comedy', 'Drama'],
     ['Animation', 'Action', 'Adventure'],
     ['Horror'],
     ['Action', 'Biography', 'Crime'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Drama', 'Romance'],
     ['Drama', 'Mystery', 'Thriller'],
     ['Drama', 'History', 'Thriller'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Adventure', 'Comedy'],
     ['Action', 'Thriller'],
     ['Comedy', 'Music'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Crime', 'Drama', 'Thriller'],
     ['Action', 'Adventure', 'Crime'],
     ['Comedy', 'Drama', 'Horror'],
     ['Drama'],
     ['Drama', 'Mystery', 'Romance'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Drama'],
     ['Action', 'Drama', 'Thriller'],
     ['Drama'],
     ['Action', 'Horror', 'Romance'],
     ['Action', 'Drama', 'Fantasy'],
     ['Action', 'Crime', 'Drama'],
     ['Drama', 'Fantasy', 'Romance'],
     ['Action', 'Crime', 'Thriller'],
     ['Action', 'Mystery', 'Thriller'],
     ['Horror', 'Mystery', 'Thriller'],
     ['Action', 'Horror', 'Sci-Fi'],
     ['Comedy', 'Drama'],
     ['Comedy'],
     ['Action', 'Adventure', 'Horror'],
     ['Action', 'Adventure', 'Thriller'],
     ['Action', 'Crime', 'Drama'],
     ['Comedy', 'Crime', 'Drama'],
     ['Drama', 'Romance'],
     ['Drama', 'Thriller'],
     ['Action', 'Comedy', 'Crime'],
     ['Comedy'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Drama', 'Romance'],
     ['Animation', 'Family', 'Fantasy'],
     ['Drama', 'Romance'],
     ['Thriller'],
     ['Adventure', 'Horror', 'Mystery'],
     ['Action', 'Sci-Fi'],
     ['Adventure', 'Comedy', 'Drama'],
     ['Animation', 'Action', 'Adventure'],
     ['Drama', 'Horror'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Comedy', 'Drama'],
     ['Action', 'Horror', 'Mystery'],
     ['Action', 'Thriller'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Drama'],
     ['Comedy', 'Drama', 'Romance'],
     ['Comedy', 'Crime'],
     ['Comedy', 'Romance'],
     ['Drama', 'Romance'],
     ['Crime', 'Drama', 'Thriller'],
     ['Horror', 'Mystery', 'Thriller'],
     ['Biography', 'Drama'],
     ['Drama', 'Mystery', 'Sci-Fi'],
     ['Adventure', 'Comedy', 'Family'],
     ['Action', 'Adventure', 'Crime'],
     ['Action', 'Crime', 'Mystery'],
     ['Mystery', 'Thriller'],
     ['Action', 'Sci-Fi', 'Thriller'],
     ['Action', 'Comedy', 'Crime'],
     ['Biography', 'Crime', 'Drama'],
     ['Biography', 'Drama', 'History'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Biography', 'Drama', 'History'],
     ['Biography', 'Comedy', 'Drama'],
     ['Drama', 'Thriller'],
     ['Horror', 'Thriller'],
     ['Drama'],
     ['Drama', 'War'],
     ['Comedy', 'Drama', 'Romance'],
     ['Drama', 'Romance', 'Sci-Fi'],
     ['Action', 'Crime', 'Drama'],
     ['Comedy', 'Drama'],
     ['Animation', 'Action', 'Adventure'],
     ['Adventure', 'Comedy', 'Drama'],
     ['Comedy', 'Drama', 'Family'],
     ['Drama', 'Romance', 'Thriller'],
     ['Comedy', 'Crime', 'Drama'],
     ['Animation', 'Comedy', 'Family'],
     ['Drama', 'Horror', 'Sci-Fi'],
     ['Action', 'Adventure', 'Drama'],
     ['Action', 'Horror', 'Sci-Fi'],
     ['Action', 'Crime', 'Sport'],
     ['Drama', 'Horror', 'Sci-Fi'],
     ['Drama', 'Horror', 'Sci-Fi'],
     ['Action', 'Adventure', 'Comedy'],
     ['Mystery', 'Sci-Fi', 'Thriller'],
     ['Crime', 'Drama', 'Thriller'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Action', 'Sci-Fi', 'Thriller'],
     ['Drama', 'Romance'],
     ['Crime', 'Drama', 'Thriller'],
     ['Comedy', 'Drama', 'Music'],
     ['Drama', 'Fantasy', 'Romance'],
     ['Crime', 'Drama', 'Thriller'],
     ['Crime', 'Drama', 'Thriller'],
     ['Comedy', 'Drama', 'Romance'],
     ['Comedy', 'Romance'],
     ['Drama', 'Sci-Fi', 'Thriller'],
     ['Drama', 'War'],
     ['Action', 'Crime', 'Drama'],
     ['Sci-Fi', 'Thriller'],
     ['Adventure', 'Drama', 'Horror'],
     ['Comedy', 'Drama', 'Music'],
     ['Comedy', 'Drama', 'Romance'],
     ['Action', 'Adventure', 'Drama'],
     ['Action', 'Crime', 'Drama'],
     ['Adventure', 'Fantasy'],
     ['Drama', 'Romance'],
     ['Biography', 'History', 'Thriller'],
     ['Crime', 'Drama', 'Thriller'],
     ['Action', 'Drama', 'History'],
     ['Biography', 'Comedy', 'Drama'],
     ['Crime', 'Drama', 'Thriller'],
     ['Action', 'Biography', 'Drama'],
     ['Action', 'Drama', 'Sci-Fi'],
     ['Adventure', 'Horror'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Adventure', 'Mystery'],
     ['Comedy', 'Drama', 'Romance'],
     ['Horror', 'Thriller'],
     ['Action', 'Sci-Fi', 'Thriller'],
     ['Action', 'Sci-Fi', 'Thriller'],
     ['Biography', 'Drama'],
     ['Action', 'Crime', 'Drama'],
     ['Action', 'Crime', 'Mystery'],
     ['Action', 'Adventure', 'Comedy'],
     ['Crime', 'Drama', 'Thriller'],
     ['Crime', 'Drama'],
     ['Mystery', 'Thriller'],
     ['Mystery', 'Sci-Fi', 'Thriller'],
     ['Action', 'Mystery', 'Sci-Fi'],
     ['Drama', 'Romance'],
     ['Drama', 'Thriller'],
     ['Drama', 'Mystery', 'Sci-Fi'],
     ['Comedy', 'Drama'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Biography', 'Drama', 'Sport'],
     ['Drama'],
     ['Comedy', 'Drama', 'Romance'],
     ['Biography', 'Drama', 'Romance'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Drama', 'Sci-Fi', 'Thriller'],
     ['Drama', 'Romance', 'Thriller'],
     ['Mystery', 'Thriller'],
     ['Mystery', 'Thriller'],
     ['Action', 'Drama', 'Fantasy'],
     ['Action', 'Adventure', 'Biography'],
     ['Adventure', 'Comedy', 'Sci-Fi'],
     ['Action', 'Adventure', 'Thriller'],
     ['Fantasy', 'Horror'],
     ['Horror', 'Mystery'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Action', 'Adventure', 'Drama'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Comedy', 'Drama'],
     ['Comedy', 'Drama'],
     ['Crime', 'Drama', 'Thriller'],
     ['Comedy', 'Romance'],
     ['Animation', 'Comedy', 'Family'],
     ['Comedy', 'Drama'],
     ['Comedy', 'Drama'],
     ['Biography', 'Drama', 'Sport'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Drama', 'History'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Adventure', 'Mystery'],
     ['Crime', 'Drama', 'Mystery'],
     ['Action'],
     ['Action', 'Adventure', 'Family'],
     ['Comedy', 'Romance'],
     ['Comedy', 'Drama', 'Romance'],
     ['Biography', 'Drama', 'Sport'],
     ['Action', 'Fantasy', 'Thriller'],
     ['Biography', 'Drama', 'Sport'],
     ['Action', 'Drama', 'Fantasy'],
     ['Adventure', 'Sci-Fi', 'Thriller'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Drama', 'Mystery', 'Thriller'],
     ['Drama', 'Romance'],
     ['Crime', 'Drama', 'Mystery'],
     ['Comedy', 'Romance', 'Sport'],
     ['Comedy', 'Family'],
     ['Drama', 'Horror', 'Mystery'],
     ['Action', 'Drama', 'Sport'],
     ['Action', 'Adventure', 'Comedy'],
     ['Drama', 'Mystery', 'Sci-Fi'],
     ['Animation', 'Action', 'Comedy'],
     ['Action', 'Crime', 'Drama'],
     ['Action', 'Crime', 'Drama'],
     ['Comedy', 'Drama', 'Romance'],
     ['Animation', 'Action', 'Adventure'],
     ['Crime', 'Drama'],
     ['Drama'],
     ['Drama'],
     ['Comedy', 'Crime'],
     ['Drama'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Drama', 'Fantasy', 'Romance'],
     ['Comedy', 'Drama'],
     ['Drama', 'Fantasy', 'Thriller'],
     ['Biography', 'Crime', 'Drama'],
     ['Comedy', 'Drama', 'Romance'],
     ['Action', 'Crime', 'Drama'],
     ['Sci-Fi'],
     ['Action', 'Biography', 'Drama'],
     ['Action', 'Comedy', 'Romance'],
     ['Adventure', 'Comedy', 'Drama'],
     ['Comedy', 'Crime', 'Drama'],
     ['Action', 'Fantasy', 'Horror'],
     ['Drama', 'Horror'],
     ['Horror'],
     ['Action', 'Thriller'],
     ['Action', 'Adventure', 'Mystery'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Comedy', 'Drama', 'Romance'],
     ['Crime', 'Drama', 'Mystery'],
     ['Adventure', 'Comedy', 'Family'],
     ['Comedy', 'Drama', 'Romance'],
     ['Comedy'],
     ['Comedy', 'Drama', 'Horror'],
     ['Drama', 'Horror', 'Thriller'],
     ['Animation', 'Adventure', 'Family'],
     ['Comedy', 'Romance'],
     ['Mystery', 'Romance', 'Sci-Fi'],
     ['Crime', 'Drama'],
     ['Drama', 'Horror', 'Mystery'],
     ['Comedy'],
     ['Biography', 'Drama'],
     ['Comedy', 'Drama', 'Thriller'],
     ['Comedy', 'Western'],
     ['Drama', 'History', 'War'],
     ['Drama', 'Horror', 'Sci-Fi'],
     ['Drama'],
     ['Comedy', 'Drama'],
     ['Fantasy', 'Horror', 'Thriller'],
     ['Drama', 'Romance'],
     ['Action', 'Comedy', 'Fantasy'],
     ['Drama', 'Horror', 'Musical'],
     ['Crime', 'Drama', 'Mystery'],
     ['Horror', 'Mystery', 'Thriller'],
     ['Comedy', 'Music'],
     ['Drama'],
     ['Biography', 'Crime', 'Drama'],
     ['Drama'],
     ['Action', 'Adventure', 'Comedy'],
     ['Crime', 'Drama', 'Mystery'],
     ['Drama'],
     ['Action', 'Comedy', 'Crime'],
     ['Comedy', 'Drama', 'Romance'],
     ['Crime', 'Drama', 'Mystery'],
     ['Action', 'Comedy', 'Crime'],
     ['Drama'],
     ['Drama', 'Romance'],
     ['Crime', 'Drama', 'Mystery'],
     ['Adventure', 'Comedy', 'Romance'],
     ['Comedy', 'Crime', 'Drama'],
     ['Adventure', 'Drama', 'Thriller'],
     ['Biography', 'Crime', 'Drama'],
     ['Crime', 'Drama', 'Thriller'],
     ['Drama', 'History', 'Thriller'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Comedy'],
     ['Horror'],
     ['Action', 'Crime', 'Mystery'],
     ['Comedy', 'Romance'],
     ['Comedy'],
     ['Action', 'Drama', 'Thriller'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Drama', 'Mystery', 'Thriller'],
     ['Comedy', 'Drama', 'Romance'],
     ['Action', 'Fantasy', 'Horror'],
     ['Drama', 'Romance'],
     ['Biography', 'Drama'],
     ['Biography', 'Drama'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Drama', 'Mystery', 'Thriller'],
     ['Action', 'Horror', 'Sci-Fi'],
     ['Drama', 'Romance'],
     ['Biography', 'Drama'],
     ['Action', 'Adventure', 'Drama'],
     ['Adventure', 'Drama', 'Fantasy'],
     ['Drama', 'Family'],
     ['Comedy', 'Drama', 'Romance'],
     ['Drama', 'Romance', 'Sci-Fi'],
     ['Action', 'Adventure', 'Thriller'],
     ['Comedy', 'Romance'],
     ['Crime', 'Drama', 'Horror'],
     ['Comedy', 'Fantasy'],
     ['Action', 'Comedy', 'Crime'],
     ['Adventure', 'Drama', 'Romance'],
     ['Action', 'Crime', 'Drama'],
     ['Crime', 'Horror', 'Thriller'],
     ['Romance', 'Sci-Fi', 'Thriller'],
     ['Comedy', 'Drama', 'Romance'],
     ['Crime', 'Drama'],
     ['Crime', 'Drama', 'Mystery'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Animation', 'Fantasy'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Drama', 'Mystery', 'War'],
     ['Comedy', 'Romance'],
     ['Animation', 'Comedy', 'Family'],
     ['Comedy'],
     ['Horror', 'Mystery', 'Thriller'],
     ['Action', 'Adventure', 'Drama'],
     ['Comedy'],
     ['Drama'],
     ['Adventure', 'Biography', 'Drama'],
     ['Comedy'],
     ['Horror', 'Thriller'],
     ['Action', 'Drama', 'Family'],
     ['Comedy', 'Fantasy', 'Horror'],
     ['Comedy', 'Romance'],
     ['Drama', 'Mystery', 'Romance'],
     ['Action', 'Adventure', 'Comedy'],
     ['Thriller'],
     ['Comedy'],
     ['Adventure', 'Comedy', 'Sci-Fi'],
     ['Comedy', 'Drama', 'Fantasy'],
     ['Mystery', 'Thriller'],
     ['Comedy', 'Drama'],
     ['Adventure', 'Drama', 'Family'],
     ['Horror', 'Thriller'],
     ['Action', 'Drama', 'Romance'],
     ['Drama', 'Romance'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Comedy'],
     ['Action', 'Biography', 'Drama'],
     ['Drama', 'Mystery', 'Romance'],
     ['Adventure', 'Drama', 'Western'],
     ['Drama', 'Music', 'Romance'],
     ['Comedy', 'Romance', 'Western'],
     ['Thriller'],
     ['Comedy', 'Drama', 'Romance'],
     ['Horror', 'Thriller'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Crime', 'Drama', 'Mystery'],
     ['Horror', 'Mystery'],
     ['Comedy', 'Crime', 'Drama'],
     ['Action', 'Comedy', 'Romance'],
     ['Biography', 'Drama', 'History'],
     ['Adventure', 'Drama'],
     ['Drama', 'Thriller'],
     ['Drama'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Biography', 'Drama'],
     ['Drama', 'Music'],
     ['Comedy', 'Drama'],
     ['Drama', 'Thriller', 'War'],
     ['Action', 'Mystery', 'Thriller'],
     ['Horror', 'Sci-Fi', 'Thriller'],
     ['Comedy', 'Drama', 'Romance'],
     ['Action', 'Sci-Fi'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Drama', 'Mystery', 'Romance'],
     ['Drama'],
     ['Action', 'Adventure', 'Thriller'],
     ['Action', 'Crime', 'Thriller'],
     ['Animation', 'Action', 'Adventure'],
     ['Drama', 'Fantasy', 'Mystery'],
     ['Drama', 'Sci-Fi'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Horror', 'Thriller'],
     ['Action', 'Thriller'],
     ['Comedy'],
     ['Biography', 'Drama'],
     ['Action', 'Mystery', 'Thriller'],
     ['Action', 'Mystery', 'Sci-Fi'],
     ['Crime', 'Drama', 'Thriller'],
     ['Comedy', 'Romance'],
     ['Comedy', 'Drama', 'Romance'],
     ['Biography', 'Drama', 'Thriller'],
     ['Drama'],
     ['Action', 'Adventure', 'Family'],
     ['Animation', 'Comedy', 'Family'],
     ['Action', 'Crime', 'Drama'],
     ['Comedy'],
     ['Comedy', 'Crime', 'Thriller'],
     ['Comedy', 'Romance'],
     ['Animation', 'Comedy', 'Drama'],
     ['Action', 'Crime', 'Thriller'],
     ['Comedy', 'Romance'],
     ['Adventure', 'Biography', 'Drama'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Crime', 'Drama', 'Mystery'],
     ['Action', 'Comedy', 'Sci-Fi'],
     ['Comedy', 'Fantasy', 'Horror'],
     ['Comedy', 'Crime'],
     ['Animation', 'Action', 'Adventure'],
     ['Action', 'Drama', 'Thriller'],
     ['Fantasy', 'Horror'],
     ['Crime', 'Drama', 'Thriller'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Comedy', 'Drama', 'Romance'],
     ['Biography', 'Drama', 'Romance'],
     ['Action', 'Drama', 'History'],
     ['Action', 'Adventure', 'Comedy'],
     ['Horror', 'Thriller'],
     ['Horror', 'Mystery', 'Thriller'],
     ['Comedy', 'Romance'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Crime', 'Drama', 'Mystery'],
     ['Crime', 'Drama', 'Mystery'],
     ['Adventure', 'Biography', 'Drama'],
     ['Horror', 'Mystery', 'Thriller'],
     ['Horror', 'Thriller'],
     ['Drama', 'Romance', 'War'],
     ['Adventure', 'Fantasy', 'Mystery'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Biography', 'Drama'],
     ['Drama', 'Thriller'],
     ['Horror', 'Thriller'],
     ['Drama', 'Horror', 'Thriller'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Horror', 'Thriller'],
     ['Comedy'],
     ['Drama', 'Sport'],
     ['Comedy', 'Family'],
     ['Drama', 'Romance'],
     ['Action', 'Adventure', 'Comedy'],
     ['Comedy'],
     ['Mystery', 'Romance', 'Thriller'],
     ['Crime', 'Drama'],
     ['Action', 'Comedy'],
     ['Crime', 'Drama', 'Mystery'],
     ['Biography', 'Drama', 'Romance'],
     ['Comedy', 'Crime'],
     ['Drama', 'Thriller'],
     ['Drama'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Action', 'Thriller'],
     ['Drama', 'Thriller'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Crime', 'Drama', 'Mystery'],
     ['Thriller'],
     ['Biography', 'Drama', 'Sport'],
     ['Crime', 'Drama', 'Thriller'],
     ['Drama', 'Music'],
     ['Crime', 'Drama', 'Thriller'],
     ['Drama', 'Romance'],
     ['Animation', 'Action', 'Adventure'],
     ['Comedy', 'Drama'],
     ['Action', 'Adventure', 'Drama'],
     ['Biography', 'Crime', 'Drama'],
     ['Horror'],
     ['Biography', 'Drama', 'Mystery'],
     ['Drama', 'Romance'],
     ['Animation', 'Drama', 'Romance'],
     ['Comedy', 'Family'],
     ['Drama'],
     ['Mystery', 'Thriller'],
     ['Drama', 'Fantasy', 'Horror'],
     ['Drama', 'Romance'],
     ['Biography', 'Drama', 'History'],
     ['Comedy', 'Family'],
     ['Action', 'Adventure', 'Thriller'],
     ['Comedy', 'Drama'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Thriller'],
     ['Drama', 'Romance'],
     ['Comedy', 'Drama', 'Romance'],
     ['Drama', 'Horror', 'Sci-Fi'],
     ['Comedy', 'Horror', 'Romance'],
     ['Drama'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Action', 'Adventure', 'Drama'],
     ['Biography', 'Comedy', 'Drama'],
     ['Drama', 'Mystery', 'Romance'],
     ['Animation', 'Adventure', 'Comedy'],
     ['Drama', 'Romance', 'Sci-Fi'],
     ['Drama'],
     ['Drama', 'Fantasy'],
     ['Drama', 'Romance'],
     ['Comedy', 'Horror', 'Thriller'],
     ['Comedy', 'Drama', 'Romance'],
     ['Crime', 'Drama'],
     ['Comedy', 'Romance'],
     ['Action', 'Drama', 'Family'],
     ['Comedy', 'Drama', 'Romance'],
     ['Action', 'Thriller', 'War'],
     ['Action', 'Comedy', 'Horror'],
     ['Biography', 'Drama', 'Sport'],
     ['Adventure', 'Comedy', 'Drama'],
     ['Comedy', 'Romance'],
     ['Comedy', 'Romance'],
     ['Comedy', 'Drama', 'Romance'],
     ['Action', 'Adventure', 'Crime'],
     ['Comedy', 'Romance'],
     ['Animation', 'Action', 'Adventure'],
     ['Action', 'Crime', 'Sci-Fi'],
     ['Drama'],
     ['Comedy', 'Drama', 'Romance'],
     ['Crime', 'Thriller'],
     ['Comedy', 'Horror', 'Sci-Fi'],
     ['Drama', 'Thriller'],
     ['Drama', 'Fantasy', 'Horror'],
     ['Thriller'],
     ['Adventure', 'Drama', 'Family'],
     ['Mystery', 'Sci-Fi', 'Thriller'],
     ['Biography', 'Crime', 'Drama'],
     ['Drama', 'Fantasy', 'Horror'],
     ['Action', 'Adventure', 'Thriller'],
     ['Crime', 'Drama', 'Horror'],
     ['Crime', 'Drama', 'Fantasy'],
     ['Adventure', 'Family', 'Fantasy'],
     ['Action', 'Adventure', 'Drama'],
     ['Action', 'Comedy', 'Horror'],
     ['Comedy', 'Drama', 'Family'],
     ['Action', 'Thriller'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Adventure', 'Drama', 'Fantasy'],
     ['Drama'],
     ['Drama'],
     ['Comedy'],
     ['Drama'],
     ['Comedy', 'Drama', 'Music'],
     ['Drama', 'Fantasy', 'Music'],
     ['Drama'],
     ['Thriller'],
     ['Comedy', 'Horror'],
     ['Action', 'Comedy', 'Sport'],
     ['Horror'],
     ['Comedy', 'Drama'],
     ['Action', 'Drama', 'Thriller'],
     ['Drama', 'Romance'],
     ['Horror', 'Mystery'],
     ['Adventure', 'Drama', 'Fantasy'],
     ['Thriller'],
     ['Comedy', 'Romance'],
     ['Action', 'Sci-Fi', 'Thriller'],
     ['Fantasy', 'Mystery', 'Thriller'],
     ['Biography', 'Drama'],
     ['Crime', 'Drama'],
     ['Action', 'Adventure', 'Sci-Fi'],
     ['Adventure'],
     ['Comedy', 'Drama'],
     ['Comedy', 'Drama'],
     ['Comedy', 'Drama', 'Romance'],
     ['Adventure', 'Comedy', 'Drama'],
     ['Action', 'Sci-Fi', 'Thriller'],
     ['Comedy', 'Romance'],
     ['Action', 'Fantasy', 'Horror'],
     ['Crime', 'Drama', 'Thriller'],
     ['Action', 'Drama', 'Thriller'],
     ['Crime', 'Drama', 'Mystery'],
     ['Crime', 'Drama', 'Mystery'],
     ['Drama', 'Sci-Fi', 'Thriller'],
     ['Biography', 'Drama', 'History'],
     ['Crime', 'Horror', 'Thriller'],
     ['Drama'],
     ['Drama', 'Mystery', 'Thriller'],
     ['Adventure', 'Biography'],
     ['Adventure', 'Biography', 'Crime'],
     ['Action', 'Horror', 'Thriller'],
     ['Action', 'Adventure', 'Western'],
     ['Horror', 'Thriller'],
     ['Drama', 'Mystery', 'Thriller'],
     ['Comedy', 'Drama', 'Musical'],
     ['Horror', 'Mystery'],
     ['Biography', 'Drama', 'Sport'],
     ['Comedy', 'Family', 'Romance'],
     ['Drama', 'Mystery', 'Thriller'],
     ['Comedy'],
     ['Drama'],
     ['Drama', 'Thriller'],
     ['Biography', 'Drama', 'Family'],
     ['Comedy', 'Drama', 'Family'],
     ['Drama', 'Fantasy', 'Musical'],
     ['Comedy'],
     ['Adventure', 'Family'],
     ['Adventure', 'Comedy', 'Fantasy'],
     ['Horror', 'Thriller'],
     ['Drama', 'Romance'],
     ['Horror'],
     ['Biography', 'Drama', 'History'],
     ['Action', 'Adventure', 'Fantasy'],
     ['Drama', 'Family', 'Music'],
     ['Comedy', 'Drama', 'Romance'],
     ['Action', 'Adventure', 'Horror'],
     ['Comedy'],
     ['Crime', 'Drama', 'Mystery'],
     ['Horror'],
     ['Drama', 'Music', 'Romance'],
     ['Adventure', 'Comedy'],
     ['Comedy', 'Family', 'Fantasy']]




```python
one_d=[]
for item in list1:
    for item1 in item:
        one_d.append(item1)
```


```python
one_d
```




    ['Action',
     'Adventure',
     'Sci-Fi',
     'Adventure',
     'Mystery',
     'Sci-Fi',
     'Horror',
     'Thriller',
     'Animation',
     'Comedy',
     'Family',
     'Action',
     'Adventure',
     'Fantasy',
     'Action',
     'Adventure',
     'Fantasy',
     'Comedy',
     'Drama',
     'Music',
     'Comedy',
     'Action',
     'Adventure',
     'Biography',
     'Adventure',
     'Drama',
     'Romance',
     'Adventure',
     'Family',
     'Fantasy',
     'Biography',
     'Drama',
     'History',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Animation',
     'Adventure',
     'Comedy',
     'Action',
     'Comedy',
     'Drama',
     'Animation',
     'Adventure',
     'Comedy',
     'Biography',
     'Drama',
     'History',
     'Action',
     'Thriller',
     'Biography',
     'Drama',
     'Drama',
     'Mystery',
     'Sci-Fi',
     'Adventure',
     'Drama',
     'Thriller',
     'Drama',
     'Crime',
     'Drama',
     'Horror',
     'Animation',
     'Adventure',
     'Comedy',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Comedy',
     'Action',
     'Adventure',
     'Drama',
     'Horror',
     'Thriller',
     'Comedy',
     'Action',
     'Adventure',
     'Drama',
     'Comedy',
     'Drama',
     'Thriller',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Action',
     'Adventure',
     'Comedy',
     'Action',
     'Horror',
     'Sci-Fi',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Adventure',
     'Drama',
     'Sci-Fi',
     'Action',
     'Adventure',
     'Fantasy',
     'Action',
     'Adventure',
     'Western',
     'Comedy',
     'Drama',
     'Animation',
     'Adventure',
     'Comedy',
     'Drama',
     'Horror',
     'Biography',
     'Drama',
     'History',
     'Drama',
     'Action',
     'Adventure',
     'Fantasy',
     'Drama',
     'Thriller',
     'Adventure',
     'Drama',
     'Fantasy',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Drama',
     'Action',
     'Adventure',
     'Fantasy',
     'Action',
     'Adventure',
     'Fantasy',
     'Comedy',
     'Drama',
     'Action',
     'Crime',
     'Thriller',
     'Action',
     'Crime',
     'Drama',
     'Adventure',
     'Drama',
     'History',
     'Crime',
     'Horror',
     'Thriller',
     'Drama',
     'Romance',
     'Comedy',
     'Drama',
     'Romance',
     'Biography',
     'Drama',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Horror',
     'Mystery',
     'Thriller',
     'Crime',
     'Drama',
     'Mystery',
     'Drama',
     'Romance',
     'Thriller',
     'Drama',
     'Mystery',
     'Sci-Fi',
     'Action',
     'Adventure',
     'Comedy',
     'Drama',
     'History',
     'Thriller',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Drama',
     'Action',
     'Drama',
     'Thriller',
     'Drama',
     'History',
     'Action',
     'Drama',
     'Romance',
     'Drama',
     'Fantasy',
     'Drama',
     'Romance',
     'Animation',
     'Adventure',
     'Comedy',
     'Action',
     'Adventure',
     'Fantasy',
     'Action',
     'Sci-Fi',
     'Adventure',
     'Drama',
     'War',
     'Action',
     'Adventure',
     'Fantasy',
     'Action',
     'Comedy',
     'Fantasy',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Comedy',
     'Drama',
     'Biography',
     'Comedy',
     'Crime',
     'Crime',
     'Drama',
     'Mystery',
     'Action',
     'Crime',
     'Thriller',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Crime',
     'Drama',
     'Action',
     'Adventure',
     'Fantasy',
     'Crime',
     'Drama',
     'Mystery',
     'Action',
     'Crime',
     'Drama',
     'Crime',
     'Drama',
     'Mystery',
     'Action',
     'Adventure',
     'Fantasy',
     'Drama',
     'Comedy',
     'Crime',
     'Drama',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Action',
     'Comedy',
     'Crime',
     'Animation',
     'Drama',
     'Fantasy',
     'Horror',
     'Mystery',
     'Sci-Fi',
     'Drama',
     'Mystery',
     'Thriller',
     'Crime',
     'Drama',
     'Thriller',
     'Biography',
     'Crime',
     'Drama',
     'Action',
     'Adventure',
     'Fantasy',
     'Adventure',
     'Drama',
     'Sci-Fi',
     'Crime',
     'Mystery',
     'Thriller',
     'Action',
     'Adventure',
     'Comedy',
     'Crime',
     'Drama',
     'Thriller',
     'Comedy',
     'Action',
     'Adventure',
     'Drama',
     'Drama',
     'Drama',
     'Mystery',
     'Sci-Fi',
     'Action',
     'Horror',
     'Thriller',
     'Biography',
     'Drama',
     'History',
     'Romance',
     'Sci-Fi',
     'Action',
     'Fantasy',
     'War',
     'Adventure',
     'Drama',
     'Fantasy',
     'Comedy',
     'Horror',
     'Thriller',
     'Action',
     'Biography',
     'Drama',
     'Drama',
     'Horror',
     'Mystery',
     'Animation',
     'Adventure',
     'Comedy',
     'Adventure',
     'Drama',
     'Family',
     'Adventure',
     'Mystery',
     'Sci-Fi',
     'Adventure',
     'Comedy',
     'Romance',
     'Action',
     'Action',
     'Thriller',
     'Adventure',
     'Drama',
     'Family',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Adventure',
     'Crime',
     'Mystery',
     'Comedy',
     'Family',
     'Musical',
     'Adventure',
     'Drama',
     'Thriller',
     'Drama',
     'Adventure',
     'Comedy',
     'Drama',
     'Drama',
     'Horror',
     'Thriller',
     'Drama',
     'Music',
     'Action',
     'Crime',
     'Thriller',
     'Crime',
     'Drama',
     'Thriller',
     'Crime',
     'Drama',
     'Thriller',
     'Drama',
     'Romance',
     'Mystery',
     'Thriller',
     'Mystery',
     'Thriller',
     'Western',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Comedy',
     'Family',
     'Biography',
     'Comedy',
     'Drama',
     'Drama',
     'Drama',
     'Western',
     'Drama',
     'Mystery',
     'Romance',
     'Comedy',
     'Drama',
     'Action',
     'Drama',
     'Mystery',
     'Comedy',
     'Action',
     'Adventure',
     'Crime',
     'Adventure',
     'Family',
     'Fantasy',
     'Adventure',
     'Sci-Fi',
     'Thriller',
     'Drama',
     'Action',
     'Crime',
     'Drama',
     'Drama',
     'Horror',
     'Mystery',
     'Action',
     'Horror',
     'Sci-Fi',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Comedy',
     'Drama',
     'Romance',
     'Action',
     'Comedy',
     'Fantasy',
     'Action',
     'Comedy',
     'Mystery',
     'Thriller',
     'War',
     'Action',
     'Comedy',
     'Crime',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Action',
     'Adventure',
     'Crime',
     'Action',
     'Adventure',
     'Thriller',
     'Drama',
     'Fantasy',
     'Romance',
     'Action',
     'Adventure',
     'Comedy',
     'Biography',
     'Drama',
     'History',
     'Action',
     'Drama',
     'History',
     'Action',
     'Adventure',
     'Thriller',
     'Crime',
     'Drama',
     'Thriller',
     'Animation',
     'Adventure',
     'Family',
     'Adventure',
     'Horror',
     'Drama',
     'Romance',
     'Sci-Fi',
     'Animation',
     'Adventure',
     'Comedy',
     'Action',
     'Adventure',
     'Family',
     'Action',
     'Adventure',
     'Drama',
     'Action',
     'Comedy',
     'Horror',
     'Mystery',
     'Thriller',
     'Action',
     'Adventure',
     'Comedy',
     'Comedy',
     'Romance',
     'Horror',
     'Mystery',
     'Drama',
     'Family',
     'Fantasy',
     'Sci-Fi',
     'Drama',
     'Thriller',
     'Drama',
     'Romance',
     'Drama',
     'War',
     'Drama',
     'Fantasy',
     'Horror',
     'Crime',
     'Drama',
     'Comedy',
     'Drama',
     'Romance',
     'Drama',
     'Romance',
     'Drama',
     'Crime',
     'Drama',
     'History',
     'Horror',
     'Sci-Fi',
     'Thriller',
     'Action',
     'Drama',
     'Sport',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Crime',
     'Drama',
     'Thriller',
     'Adventure',
     'Biography',
     'Drama',
     'Biography',
     'Drama',
     'Thriller',
     'Action',
     'Comedy',
     'Crime',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Drama',
     'Fantasy',
     'Horror',
     'Biography',
     'Drama',
     'Thriller',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Action',
     'Adventure',
     'Mystery',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Drama',
     'Horror',
     'Comedy',
     'Drama',
     'Romance',
     'Comedy',
     'Romance',
     'Drama',
     'Horror',
     'Thriller',
     'Action',
     'Adventure',
     'Drama',
     'Drama',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Action',
     'Drama',
     'Mystery',
     'Action',
     'Adventure',
     'Fantasy',
     'Action',
     'Adventure',
     'Fantasy',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Action',
     'Adventure',
     'Comedy',
     'Drama',
     'Horror',
     'Action',
     'Comedy',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Animation',
     'Adventure',
     'Comedy',
     'Horror',
     'Mystery',
     'Crime',
     'Drama',
     'Mystery',
     'Comedy',
     'Crime',
     'Drama',
     'Comedy',
     'Drama',
     'Romance',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Action',
     'Adventure',
     'Family',
     'Horror',
     'Sci-Fi',
     'Thriller',
     'Drama',
     'Fantasy',
     'War',
     'Crime',
     'Drama',
     'Thriller',
     'Action',
     'Adventure',
     'Drama',
     'Action',
     'Adventure',
     'Thriller',
     'Action',
     'Adventure',
     'Drama',
     'Drama',
     'Romance',
     'Biography',
     'Drama',
     'History',
     'Drama',
     'Horror',
     'Thriller',
     'Adventure',
     'Comedy',
     'Drama',
     'Action',
     'Adventure',
     'Romance',
     'Action',
     'Drama',
     'War',
     'Animation',
     'Adventure',
     'Comedy',
     'Animation',
     'Adventure',
     'Comedy',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Adventure',
     'Family',
     'Fantasy',
     'Drama',
     'Musical',
     'Romance',
     'Drama',
     'Sci-Fi',
     'Thriller',
     'Comedy',
     'Drama',
     'Action',
     'Comedy',
     'Crime',
     'Biography',
     'Comedy',
     'Drama',
     'Comedy',
     'Drama',
     'Romance',
     'Drama',
     'Thriller',
     'Biography',
     'Drama',
     'History',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Horror',
     'Mystery',
     'Thriller',
     'Comedy',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Action',
     'Drama',
     'Sci-Fi',
     'Horror',
     'Drama',
     'Thriller',
     'Comedy',
     'Drama',
     'Romance',
     'Drama',
     'Thriller',
     'Comedy',
     'Drama',
     'Drama',
     'Action',
     'Adventure',
     'Comedy',
     'Drama',
     'Horror',
     'Thriller',
     'Comedy',
     'Drama',
     'Sci-Fi',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Horror',
     'Action',
     'Adventure',
     'Thriller',
     'Adventure',
     'Fantasy',
     'Action',
     'Comedy',
     'Crime',
     'Comedy',
     'Drama',
     'Music',
     'Animation',
     'Adventure',
     'Comedy',
     'Action',
     'Adventure',
     'Mystery',
     'Action',
     'Comedy',
     'Crime',
     'Crime',
     'Drama',
     'History',
     'Comedy',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Crime',
     'Mystery',
     'Thriller',
     'Action',
     'Adventure',
     'Crime',
     'Thriller',
     'Biography',
     'Drama',
     'Romance',
     'Action',
     'Adventure',
     'Action',
     'Fantasy',
     'Action',
     'Comedy',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Action',
     'Comedy',
     'Crime',
     'Thriller',
     'Action',
     'Drama',
     'Horror',
     'Comedy',
     'Music',
     'Romance',
     'Comedy',
     'Drama',
     'Action',
     'Adventure',
     'Fantasy',
     'Drama',
     'Romance',
     'Animation',
     'Adventure',
     'Comedy',
     'Comedy',
     'Drama',
     'Biography',
     'Crime',
     'Drama',
     'Drama',
     'History',
     'Action',
     'Crime',
     'Thriller',
     'Action',
     'Biography',
     'Drama',
     'Horror',
     'Comedy',
     'Romance',
     'Comedy',
     'Romance',
     'Comedy',
     'Crime',
     'Drama',
     'Adventure',
     'Family',
     'Fantasy',
     'Crime',
     'Drama',
     'Thriller',
     'Action',
     'Crime',
     'Thriller',
     'Comedy',
     'Romance',
     'Biography',
     'Drama',
     'Sport',
     'Drama',
     'Romance',
     'Drama',
     'Horror',
     'Adventure',
     'Fantasy',
     'Adventure',
     'Family',
     'Fantasy',
     'Action',
     'Drama',
     'Sci-Fi',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Action',
     'Horror',
     'Comedy',
     'Horror',
     'Thriller',
     'Action',
     'Crime',
     'Thriller',
     'Crime',
     'Drama',
     'Music',
     'Drama',
     'Action',
     'Crime',
     'Thriller',
     'Action',
     'Sci-Fi',
     'Thriller',
     'Biography',
     'Drama',
     'Action',
     'Adventure',
     'Fantasy',
     'Drama',
     'Horror',
     'Sci-Fi',
     'Biography',
     'Comedy',
     'Drama',
     'Crime',
     'Horror',
     'Thriller',
     'Crime',
     'Drama',
     'Mystery',
     'Animation',
     'Adventure',
     'Comedy',
     'Action',
     'Biography',
     'Drama',
     'Biography',
     'Drama',
     'Biography',
     'Drama',
     'History',
     'Action',
     'Biography',
     'Drama',
     'Drama',
     'Fantasy',
     'Horror',
     'Comedy',
     'Drama',
     'Romance',
     'Drama',
     'Sport',
     'Drama',
     'Romance',
     'Comedy',
     'Romance',
     'Action',
     'Crime',
     'Thriller',
     'Action',
     'Crime',
     'Drama',
     'Action',
     'Drama',
     'Thriller',
     'Adventure',
     'Family',
     'Fantasy',
     'Action',
     'Adventure',
     'Action',
     'Adventure',
     'Romance',
     'Adventure',
     'Family',
     'Fantasy',
     'Crime',
     'Drama',
     'Comedy',
     'Horror',
     'Comedy',
     'Fantasy',
     'Romance',
     'Drama',
     'Drama',
     'Comedy',
     'Drama',
     'Comedy',
     'Drama',
     'Romance',
     'Adventure',
     'Sci-Fi',
     'Thriller',
     'Action',
     'Adventure',
     'Fantasy',
     'Comedy',
     'Drama',
     'Biography',
     'Drama',
     'Romance',
     'Comedy',
     'Fantasy',
     'Comedy',
     'Drama',
     'Fantasy',
     'Comedy',
     'Horror',
     'Thriller',
     'Action',
     'Adventure',
     'Sci-Fi',
     'Adventure',
     'Comedy',
     'Horror',
     'Comedy',
     'Mystery',
     'Drama',
     'Adventure',
     'Drama',
     'Fantasy',
     'Drama',
     'Sport',
     'Action',
     'Adventure',
     'Action',
     'Adventure',
     'Drama',
     'Action',
     'Drama',
     'Sci-Fi',
     'Action',
     'Mystery',
     'Sci-Fi',
     'Action',
     'Crime',
     'Drama',
     'Action',
     'Crime',
     'Fantasy',
     'Biography',
     'Comedy',
     'Drama',
     'Action',
     'Crime',
     'Thriller',
     'Biography',
     'Crime',
     'Drama',
     'Drama',
     'Sport',
     'Adventure',
     'Comedy',
     'Drama',
     'Action',
     'Adventure',
     'Thriller',
     'Comedy',
     'Fantasy',
     'Horror',
     'Drama',
     'Sport',
     'Horror',
     'Thriller',
     'Drama',
     'History',
     'Thriller',
     'Animation',
     'Action',
     'Adventure',
     'Action',
     'Adventure',
     'Drama',
     ...]




```python
uni_list=[]
for item in one_d:
    if item not in uni_list:
        uni_list.append(item)
```


```python
uni_list
```




    ['Action',
     'Adventure',
     'Sci-Fi',
     'Mystery',
     'Horror',
     'Thriller',
     'Animation',
     'Comedy',
     'Family',
     'Fantasy',
     'Drama',
     'Music',
     'Biography',
     'Romance',
     'History',
     'Crime',
     'Western',
     'War',
     'Musical',
     'Sport']



### 23. How Many Films of Each Genre Were Made?


```python
one_d=[]
for item in list1:
    for item1 in item:
        one_d.append(item1)
```


```python
from collections import Counter
```


```python
Counter(one_d)
```




    Counter({'Drama': 513,
             'Action': 303,
             'Comedy': 279,
             'Adventure': 259,
             'Thriller': 195,
             'Crime': 150,
             'Romance': 141,
             'Sci-Fi': 120,
             'Horror': 119,
             'Mystery': 106,
             'Fantasy': 101,
             'Biography': 81,
             'Family': 51,
             'Animation': 49,
             'History': 29,
             'Sport': 18,
             'Music': 16,
             'War': 13,
             'Western': 7,
             'Musical': 5})




```python

```
